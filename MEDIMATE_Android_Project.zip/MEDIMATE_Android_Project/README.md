# MEDIMATE Android project (native daily reminders)

This project wraps the supplied `medimate.html` interface in an Android WebView and adds native Android daily alarms/notifications. The medicine editor remains in the existing HTML interface. Changes to `medimate_medicines_v1` are synchronized to Android's alarm scheduler. Alarms are restored after reboot and time/time-zone changes.

## Important safety notes

- The three sample medicines from the supplied HTML were removed. The app starts with an empty medicine list to avoid fake reminders.
- Have a caregiver verify every medicine name, dose, and time against the current prescription/clinician instructions before relying on reminders. MEDIMATE does not determine doses.
- A notification is a reminder, not proof that a dose was taken. Mark doses taken only after confirming they were actually taken.
- Android settings, manufacturer battery restrictions, notification settings, or a force-stop can affect delivery. Test on the actual phone before relying on it.
- The original HTML loads React, Tailwind, Babel, and fonts from online CDNs, so the interface needs internet to load as currently packaged. Once a schedule has synced, native Android alarms do not depend on the HTML page staying open.

## Build the APK for free using only an Android phone

This repository includes `.github/workflows/build-apk.yml`. GitHub-hosted Actions builds a debug APK in the cloud; no laptop or Android Studio is needed. Standard GitHub-hosted runners are free for public repositories according to GitHub's billing documentation.

1. Download and unzip this project on your phone.
2. In your phone browser, sign in to GitHub and create a **new public repository** named `medimate-android`. Do not upload actual medicine schedules, screenshots, or personal health data to the repository. Only the app source belongs there.
3. Use GitHub's **Add file → Upload files** to upload all project files and folders from this ZIP. Make sure `.github/workflows/build-apk.yml` is included. Commit the files to the `main` branch. (If your mobile file picker hides dot-folders, create the workflow file in GitHub's web editor at `.github/workflows/build-apk.yml`.)
4. Open the repository's **Actions** tab. Choose **Build MEDIMATE APK**, then tap **Run workflow** if it did not start automatically. Wait for the green check mark.
5. Open the completed workflow run, scroll to **Artifacts**, and download `medimate-debug-apk`. Unzip that artifact; it contains `app-debug.apk`.
6. Tap `app-debug.apk` on your phone and allow your browser/files app to install unknown apps if Android asks. Install only the APK you built from this project.
7. Open MEDIMATE. Allow notifications. When prompted, open **Alarms & reminders** settings and allow MEDIMATE to set alarms. If the prompt was skipped, open Android Settings → Apps → MEDIMATE → Special app access → Alarms & reminders.
8. Add the real schedule and save it. Keep the app open for a moment after edits so the WebView can sync changes to Android.

GitHub Actions is free for standard runners in public repositories; if you make the repository private or change account/usage settings, limits may differ.

## Test before real use

- Add a test medicine with a time 2–3 minutes ahead and a clearly labelled test name, then lock the phone.
- Confirm the notification appears and makes sound/vibration. Remove the test item afterwards.
- Repeat after swiping MEDIMATE away, after restarting the phone, and after changing the time zone if practical.
- Check Settings → Apps → MEDIMATE → Notifications and Alarms & reminders. Some Android brands also have battery/background restrictions.
- If the reminder is late or absent, do not assume a dose was taken or take an extra dose. Check the prescription/caregiver instructions.

## Technical details

- `AlarmManager.setExactAndAllowWhileIdle()` is used when exact-alarm access is granted; otherwise an inexact allow-while-idle fallback is scheduled.
- `BOOT_COMPLETED`, `TIME_SET`, and `TIMEZONE_CHANGED` rebuild the alarms from the saved schedule.
- Native schedule JSON is stored locally in app preferences. The web UI stores its editable schedule in WebView local storage.
- Notifications use a private lock-screen preview to avoid displaying medicine details on a locked screen.
