package com.medimate.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "medimate_medicine_reminders";

    @Override public void onReceive(Context context, Intent intent) {
        String stableId = intent.getStringExtra("stableId");
        String medicine = intent.getStringExtra("medicine");
        String quantity = intent.getStringExtra("quantity");
        String notes = intent.getStringExtra("notes");
        String time = intent.getStringExtra("time");
        if (medicine == null) medicine = "Your scheduled medicine";
        if (quantity == null) quantity = "";
        String content = "Time to take " + medicine + (quantity.trim().isEmpty() ? "" : " — " + quantity);
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent tap = PendingIntent.getActivity(context, 7001, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification generic = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("MEDIMATE medicine reminder")
            .setContentText("It is time for a scheduled medicine.")
            .setPriority(NotificationCompat.PRIORITY_HIGH).build();
        Notification notification = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("MEDIMATE medicine reminder")
            .setContentText(content)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(content + ((notes == null || notes.trim().isEmpty()) ? "" : "\n" + notes)))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(generic)
            .setAutoCancel(true).setContentIntent(tap)
            .setVibrate(new long[]{0, 350, 180, 350})
            .setDefaults(NotificationCompat.DEFAULT_SOUND)
            .build();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(stableId == null ? (int) System.currentTimeMillis() : stableId.hashCode(), notification);
        if (stableId != null && time != null) AlarmScheduler.scheduleNext(context, stableId, medicine, quantity, notes == null ? "" : notes, time);
    }
}
