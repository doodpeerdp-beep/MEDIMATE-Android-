package com.medimate.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class AlarmScheduler {
    private static final String PREFS = "medimate_native_schedule";
    private static final String KEY_JSON = "medicines_json";
    private static final String KEY_IDS = "scheduled_ids";
    private AlarmScheduler() {}

    public static boolean hasExactAlarmPermission(Context context) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    public static void sync(Context context, String json) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_JSON, json == null ? "[]" : json).apply();
        rescheduleAll(context);
    }

    public static void rescheduleAll(Context context) {
        String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_JSON, "[]");
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Set<String> oldIds = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(KEY_IDS, new HashSet<>());
        for (String old : new HashSet<>(oldIds)) {
            int requestCode = old.hashCode();
            Intent i = new Intent(context, AlarmReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) am.cancel(pi);
        }
        Set<String> newIds = new HashSet<>();
        try {
            JSONArray medicines = new JSONArray(json);
            for (int i = 0; i < medicines.length(); i++) {
                JSONObject med = medicines.optJSONObject(i);
                if (med == null || !med.optBoolean("isActive", true)) continue;
                String medId = med.optString("id", "medicine-" + i);
                String medName = med.optString("name", "Medicine");
                String notes = med.optString("notes", "");
                JSONArray schedules = med.optJSONArray("schedules");
                if (schedules == null) continue;
                for (int j = 0; j < schedules.length(); j++) {
                    JSONObject schedule = schedules.optJSONObject(j);
                    if (schedule == null) continue;
                    String time = schedule.optString("time", "");
                    if (!time.matches("\\d{2}:\\d{2}")) continue;
                    String scheduleId = schedule.optString("id", "schedule-" + j);
                    String stableId = medId + "::" + scheduleId;
                    newIds.add(stableId);
                    scheduleNext(context, stableId, medName, schedule.optString("quantity", ""), notes, time);
                }
            }
        } catch (Exception ignored) { }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_IDS, newIds).apply();
    }

    static void scheduleNext(Context context, String stableId, String medName, String quantity, String notes, String time) {
        scheduleNextSafe(context, stableId, medName, quantity, notes, time);
    }

    private static void scheduleNextSafe(Context context, String stableId, String medName, String quantity, String notes, String time) {
        try {
            String[] parts = time.split(":");
            int hour = Integer.parseInt(parts[0]);
            int minute = Integer.parseInt(parts[1]);
            Calendar next = Calendar.getInstance();
            next.set(Calendar.HOUR_OF_DAY, hour); next.set(Calendar.MINUTE, minute); next.set(Calendar.SECOND, 0); next.set(Calendar.MILLISECOND, 0);
            if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_YEAR, 1);
            Intent intent = new Intent(context, AlarmReceiver.class);
            intent.putExtra("stableId", stableId); intent.putExtra("medicine", medName); intent.putExtra("quantity", quantity); intent.putExtra("notes", notes); intent.putExtra("time", time);
            int requestCode = stableId.hashCode();
            PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            if (Build.VERSION.SDK_INT >= 31 && !hasExactAlarmPermission(context)) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
            else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
        } catch (SecurityException denied) {
            try {
                String[] p = time.split(":"); Calendar next = Calendar.getInstance();
                next.set(Calendar.HOUR_OF_DAY, Integer.parseInt(p[0])); next.set(Calendar.MINUTE, Integer.parseInt(p[1])); next.set(Calendar.SECOND, 0); next.set(Calendar.MILLISECOND, 0);
                if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_YEAR, 1);
                Intent intent = new Intent(context, AlarmReceiver.class); intent.putExtra("stableId", stableId); intent.putExtra("medicine", medName); intent.putExtra("quantity", quantity); intent.putExtra("notes", notes); intent.putExtra("time", time);
                PendingIntent pi = PendingIntent.getBroadcast(context, stableId.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE); if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
            } catch (Exception ignored) { }
        } catch (Exception ignored) { }
    }
}
