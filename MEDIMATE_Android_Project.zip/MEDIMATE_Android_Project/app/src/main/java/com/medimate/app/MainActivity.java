package com.medimate.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends Activity {
    private static final int REQUEST_NOTIFICATIONS = 501;
    private WebView webView;
    private boolean exactPromptShown = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new MedimateBridge(), "AndroidMedimate");
        webView.loadUrl("file:///android_asset/index.html");
        createNotificationChannel();
        requestNotificationPermissionIfNeeded();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.postDelayed(() -> {
            if (AlarmScheduler.hasExactAlarmPermission(this)) AlarmScheduler.rescheduleAll(this);
            else promptExactAlarmPermission();
        }, 500);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NOTIFICATIONS) promptExactAlarmPermission();
    }

    private void promptExactAlarmPermission() {
        if (Build.VERSION.SDK_INT < 31 || AlarmScheduler.hasExactAlarmPermission(this) || exactPromptShown || isFinishing()) return;
        exactPromptShown = true;
        new AlertDialog.Builder(this)
            .setTitle("Allow exact-time reminders")
            .setMessage("MEDIMATE needs Alarms & reminders access so medicine notifications can be scheduled close to the selected time, including when the screen is locked. If you skip this, Android may delay reminders.")
            .setNegativeButton("Not now", (d, w) -> { AlarmScheduler.rescheduleAll(this); })
            .setPositiveButton("Open settings", (d, w) -> {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); }
                catch (Exception e) { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
            }).show();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            android.app.NotificationChannel channel = new android.app.NotificationChannel(AlarmReceiver.CHANNEL_ID, "Medicine reminders", android.app.NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Scheduled MEDIMATE medicine reminders");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 350, 180, 350});
            getSystemService(android.app.NotificationManager.class).createNotificationChannel(channel);
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private class MedimateBridge {
        @JavascriptInterface public void syncMedicines(String json) { AlarmScheduler.sync(MainActivity.this, json); }
        @JavascriptInterface public void requestExactAlarmPermission() { runOnUiThread(MainActivity.this::promptExactAlarmPermission); }
    }
}
